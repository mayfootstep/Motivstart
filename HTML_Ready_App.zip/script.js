const appData = {
  startDate: new Date(),
  language: 'ar'
};

// Motivational messages in both languages
const motivationalMessages = {
  ar: [
    "كل يوم تمر به هو انتصار جديد يضاف إلى قوتك.",
    "أنت تصنع تاريخًا جديدًا لنفسك الآن، استمر في البناء.",
    "التغيير يأتي خطوة بخطوة، وأنت تخطو بثبات.",
    "قوتك تكمن في استمرارك رغم الصعوبات.",
    "كل صباح جديد هو فرصة جديدة لتكون أفضل.",
    "التحديات تصنع منك شخصًا أقوى، وأنت تتجاوزها يومًا بعد يوم.",
    "بدايتك الجديدة هي الخطوة الأولى في رحلة قوية تجاه حياة أفضل.",
    "النجاح ليس بعدم السقوط، بل بالنهوض في كل مرة تسقط فيها.",
    "أنت أقوى مما تعتقد، وتستطيع تحقيق أكثر مما تتخيل.",
    "استمر في التقدم، فالمستقبل ينتظر نسخة أفضل منك.",
    "تذكر دائمًا، أنت لست وحدك في هذه الرحلة. نحن هنا معك.",
    "كل لحظة تقاوم فيها هي خطوة نحو نسخة أقوى من نفسك.",
    "الإرادة القوية تتجاوز كل الصعوبات، وإرادتك من حديد.",
    "في كل يوم، نحن نصنع مستقبلنا بالقرارات التي نتخذها."
  ],
  en: [
    "Each day you pass is a new victory added to your strength.",
    "You are creating a new history for yourself now, keep building.",
    "Change comes step by step, and you are moving steadily.",
    "Your strength lies in your persistence despite difficulties.",
    "Each new morning is a new opportunity to be better.",
    "Challenges make you stronger, and you overcome them day by day.",
    "Your new beginning is the first step in a powerful journey toward a better life.",
    "Success is not about not falling, but about rising each time you fall.",
    "You are stronger than you think, and you can achieve more than you imagine.",
    "Keep moving forward, the future awaits a better version of you.",
    "Remember always, you are not alone on this journey. We are here with you.",
    "Every moment you resist is a step toward a stronger version of yourself.",
    "Strong will overcomes all difficulties, and your will is made of steel.",
    "Each day, we shape our future with the decisions we make."
  ]
};

// Emergency advice in both languages
const emergencyAdvice = {
  ar: [
    {
      icon: "fas fa-water",
      text: "توقف واشرب كوبًا من الماء. التنفس ببطء. ركّز على كل رشفة."
    },
    {
      icon: "fas fa-walking",
      text: "غادر المكان الذي أنت فيه الآن. قم بالمشي لمدة خمس دقائق على الأقل."
    },
    {
      icon: "fas fa-shower",
      text: "اذهب واغسل وجهك بالماء البارد. ركّز على الإحساس بالماء."
    },
    {
      icon: "fas fa-phone",
      text: "اتصل بصديق موثوق أو أحد أفراد العائلة للتحدث عن شعورك."
    },
    {
      icon: "fas fa-book",
      text: "خذ كتابًا واقرأ بعض الصفحات. غيّر مسار تفكيرك."
    },
    {
      icon: "fas fa-music",
      text: "استمع إلى موسيقى هادئة أو محفزة. دع الموسيقى تغير مزاجك."
    },
    {
      icon: "fas fa-pen",
      text: "خذ ورقة واكتب مشاعرك. اكتب كل ما يجول في خاطرك دون تردد."
    },
    {
      icon: "fas fa-brain",
      text: "تأمل لمدة 5 دقائق. ركز على تنفسك فقط، استنشق لـ 4، احبس لـ 4، زفير لـ 4."
    }
  ],
  en: [
    {
      icon: "fas fa-water",
      text: "Stop and drink a glass of water. Breathe slowly. Focus on each sip."
    },
    {
      icon: "fas fa-walking",
      text: "Leave the place you are in now. Take a walk for at least five minutes."
    },
    {
      icon: "fas fa-shower",
      text: "Go and wash your face with cold water. Focus on the sensation of water."
    },
    {
      icon: "fas fa-phone",
      text: "Call a trusted friend or family member to talk about how you feel."
    },
    {
      icon: "fas fa-book",
      text: "Take a book and read a few pages. Change your train of thought."
    },
    {
      icon: "fas fa-music",
      text: "Listen to calm or motivating music. Let the music change your mood."
    },
    {
      icon: "fas fa-pen",
      text: "Take a paper and write down your feelings. Write everything that comes to mind without hesitation."
    },
    {
      icon: "fas fa-brain",
      text: "Meditate for 5 minutes. Focus only on your breathing, inhale for 4, hold for 4, exhale for 4."
    }
  ]
};

// Initialize the app when the document is loaded
document.addEventListener('DOMContentLoaded', () => {
  // Load saved data from localStorage
  loadData();
  
  // Initialize UI elements
  updateUI();
  
  // Set up event listeners
  setupEventListeners();
  
  // Start the timer update
  startTimerUpdate();
  
  // Update motivational message every 30 seconds
  setInterval(updateMotivationalMessage, 30000);
});

// Load saved data from localStorage
function loadData() {
  const savedStartDate = localStorage.getItem('startDate');
  const savedLanguage = localStorage.getItem('language');
  
  if (savedStartDate) {
    appData.startDate = new Date(savedStartDate);
  }
  
  if (savedLanguage) {
    appData.language = savedLanguage;
  }
}

// Set up all event listeners
function setupEventListeners() {
  // Emergency button
  const emergencyButton = document.getElementById('emergency-button');
  emergencyButton.addEventListener('click', showEmergencyModal);
  
  // Close modal button
  const closeModal = document.getElementById('close-modal');
  closeModal.addEventListener('click', hideEmergencyModal);
  
  // Close modal when clicking outside
  window.addEventListener('click', (event) => {
    const modal = document.getElementById('emergency-modal');
    if (event.target === modal) {
      hideEmergencyModal();
    }
  });
}

// Start timer update loop
function startTimerUpdate() {
  updateTimer();
  // Update every second
  setInterval(updateTimer, 1000);
}

// Update the timer display
function updateTimer() {
  const now = new Date();
  const diff = now - appData.startDate;
  
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  
  // Update the timer elements with animation
  updateTimerElement('days', days);
  updateTimerElement('hours', hours);
  updateTimerElement('minutes', minutes);
  
  // Update other UI elements
  updateBadges(days);
  updateNextMilestone(days);
}

// Update a timer element with animation
function updateTimerElement(id, value) {
  const element = document.getElementById(id);
  if (element.textContent !== String(value)) {
    element.style.animation = 'none';
    element.offsetHeight; // Trigger reflow
    element.textContent = value;
    element.style.animation = 'countUp 0.5s ease-out';
  }
}

// Update badges based on days
function updateBadges(days) {
  const badges = document.querySelectorAll('.badge');
  const milestoneDays = [3, 7, 30, 90, 180, 365];
  
  for (let i = 0; i < badges.length; i++) {
    if (days >= milestoneDays[i]) {
      badges[i].classList.remove('locked');
      badges[i].classList.add('achieved');
    } else {
      badges[i].classList.remove('achieved');
      badges[i].classList.add('locked');
    }
  }
}

// Update next milestone display
function updateNextMilestone(days) {
  const milestoneDays = [3, 7, 30, 90, 180, 365];
  let nextMilestone = 365;
  
  for (let i = 0; i < milestoneDays.length; i++) {
    if (days < milestoneDays[i]) {
      nextMilestone = milestoneDays[i];
      break;
    }
  }
  
  const milestoneText = document.querySelector('.milestone-info p');
  if (appData.language === 'ar') {
    milestoneText.textContent = days >= 365 ? 'تم تحقيق جميع المراحل!' : `${nextMilestone} أيام`;
  } else {
    milestoneText.textContent = days >= 365 ? 'All milestones achieved!' : `${nextMilestone} days`;
  }
  
  let progress = 100;
  if (days < nextMilestone) {
    progress = Math.floor((days / nextMilestone) * 100);
  }
  
  document.getElementById('progress-fill').style.width = `${progress}%`;
  document.getElementById('progress-text').textContent = `${progress}%`;
}

// Update motivational message
function updateMotivationalMessage() {
  const messageElement = document.getElementById('message');
  const currentMessage = messageElement.textContent;
  let newMessage;
  
  // Make sure we don't show the same message twice
  do {
    const messageIndex = Math.floor(Math.random() * motivationalMessages[appData.language].length);
    newMessage = motivationalMessages[appData.language][messageIndex];
  } while (newMessage === currentMessage);
  
  // Animate message change
  messageElement.style.opacity = '0';
  
  setTimeout(() => {
    messageElement.textContent = newMessage;
    messageElement.style.opacity = '1';
  }, 500);
}

// Show emergency modal with advice
function showEmergencyModal() {
  const modal = document.getElementById('emergency-modal');
  const adviceContainer = document.getElementById('emergency-advice');
  
  // Clear previous advice
  adviceContainer.innerHTML = '';
  
  // Get random advice items (3-5 items)
  const numItems = Math.floor(Math.random() * 3) + 3; // 3 to 5 items
  const shuffledAdvice = [...emergencyAdvice[appData.language]].sort(() => 0.5 - Math.random());
  const selectedAdvice = shuffledAdvice.slice(0, numItems);
  
  // Create DOM elements for each advice
  selectedAdvice.forEach(advice => {
    const adviceItem = document.createElement('div');
    adviceItem.className = 'emergency-advice-item';
    
    const iconElement = document.createElement('div');
    iconElement.className = 'emergency-advice-icon';
    iconElement.innerHTML = `<i class="${advice.icon}"></i>`;
    
    const textElement = document.createElement('div');
    textElement.className = 'emergency-advice-text';
    textElement.textContent = advice.text;
    
    adviceItem.appendChild(iconElement);
    adviceItem.appendChild(textElement);
    adviceContainer.appendChild(adviceItem);
  });
  
  // Show the modal
  modal.style.display = 'flex';
}

// Hide emergency modal
function hideEmergencyModal() {
  const modal = document.getElementById('emergency-modal');
  modal.style.display = 'none';
}

// Open date picker for editing start date
function openDatePicker() {
  const dateString = prompt(
    appData.language === 'ar' 
      ? 'أدخل تاريخ البداية (YYYY-MM-DD)' 
      : 'Enter start date (YYYY-MM-DD)', 
    formatDate(appData.startDate)
  );
  
  if (dateString) {
    const newDate = new Date(dateString);
    if (!isNaN(newDate.getTime())) {
      appData.startDate = newDate;
      localStorage.setItem('startDate', newDate.toISOString());
      updateTimer();
      updateMotivationalMessage();
    } else {
      alert(appData.language === 'ar' ? 'تاريخ غير صالح' : 'Invalid date');
    }
  }
}

// Reset date to current time
function resetDate() {
  if (confirm(appData.language === 'ar' ? 'هل أنت متأكد من إعادة تعيين التاريخ؟' : 'Are you sure you want to reset the date?')) {
    appData.startDate = new Date();
    localStorage.setItem('startDate', appData.startDate.toISOString());
    updateTimer();
    updateMotivationalMessage();
  }
}

// Format date to YYYY-MM-DD
function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Switch language
function switchLanguage(lang) {
  appData.language = lang;
  localStorage.setItem('language', lang);
  updateUI();
}

// Update all UI elements based on current language
function updateUI() {
  const isArabic = appData.language === 'ar';
  
  // Update document direction and language
  document.dir = isArabic ? 'rtl' : 'ltr';
  document.documentElement.lang = appData.language;
  
  // Update language buttons
  const arButton = document.querySelector('.language-button:first-child');
  const enButton = document.querySelector('.language-button:last-child');
  
  if (isArabic) {
    arButton.classList.add('active');
    enButton.classList.remove('active');
  } else {
    arButton.classList.remove('active');
    enButton.classList.add('active');
  }
  
  // Update text elements
  document.querySelector('.header h1').textContent = isArabic ? 'رحلة التعافي' : 'Recovery Journey';
  document.getElementById('next-milestone-title').textContent = isArabic ? 'المرحلة القادمة' : 'Next Milestone';
  document.getElementById('progress-label').textContent = isArabic ? 'التقدم' : 'Progress';
  document.getElementById('achievements-title').textContent = isArabic ? 'الإنجازات' : 'Achievements';
  document.getElementById('edit-date-button').textContent = isArabic ? 'تعديل تاريخ البداية' : 'Edit Start Date';
  document.getElementById('reset-date-button').textContent = isArabic ? 'إعادة تعيين التاريخ' : 'Reset Date';
  document.getElementById('emergency-text').textContent = isArabic ? 'زر الطوارئ' : 'Emergency Button';
  document.getElementById('emergency-modal-title').textContent = isArabic ? 'نصائح للطوارئ' : 'Emergency Advice';
  
  // Update timer labels
  document.getElementById('days-label').textContent = isArabic ? 'يوم' : 'days';
  document.getElementById('hours-label').textContent = isArabic ? 'ساعة' : 'hours';
  document.getElementById('minutes-label').textContent = isArabic ? 'دقيقة' : 'minutes';
  
  // Update timer and messages
  updateTimer();
  updateMotivationalMessage();
}
